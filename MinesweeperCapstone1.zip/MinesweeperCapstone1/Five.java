import info.gridworld.actor.Actor;
import info.gridworld.grid.Location;

public class Five extends Actor
{
    public Five()
    {
        super();
    }
}