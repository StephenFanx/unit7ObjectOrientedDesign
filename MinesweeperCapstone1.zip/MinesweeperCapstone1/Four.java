import info.gridworld.actor.Actor;
import info.gridworld.grid.Location;

public class Four extends Actor
{
    public Four()
    {
        super();
    }
}