import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.grid.Grid;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * Game of Life starter code. Demonstrates how to create and populate the game using the GridWorld framework.
 * Also demonstrates how to provide accessor methods to make the class testable by unit tests.
 * 
 * @author
 * @version
 */
public class Minesweeper
{
    // the world comprised of the grid that displays the graphics for the game
    private NewGridWorld world;
    
    ArrayList<Location> mineList;
    
    // the game board will have 5 rows and 5 columns
    private final int ROWS = 16;
    private final int COLS = 20;
    
    /**
     * Default constructor for objects of class Minesweeper
     * 
     * @post    the game will be initialized with a screen of blank tiles
     * 
     */
    public Minesweeper()
    {
        // create the grid, of the specified size, that contains Actors
        BoundedGrid<Actor> grid1 = new BoundedGrid<Actor>(ROWS, COLS);
        
        ArrayList<Location> mineList = new ArrayList();
        
        // create a world based on the grid
        world = new NewGridWorld(grid1);
        grid1.addMouseListener(new MousePressListener());
        
        // populate the game
        populateGame();
        
        // display the newly constructed and populated world
        world.show();
        
    }
    
    /**
     * Creates the actors and inserts them into their initial starting positions in the grid
     *
     * @pre     the grid has been created
     * @post    all actors that comprise the initial state of the game have been added to the grid
     * 
     */
    private void populateGame()
    {
        // random locations of mines
        while (mineList.size() < 12)
        {
            Location loc = new Location((int)((Math.random()*COLS) + 1), (int)((Math.random()*ROWS)) + 1);
            for (int i = 0; i < mineList.size(); i++)
            {
                if (loc == mineList.get(i))
                {
                    mineList.add(loc);
                }
            }
        }
    }
    
    class MousePressListener implements MouseListener
    {
        public void mousePressed(MouseEvent event)
        {
            //changes the active shape to the shape the user clicks on
            //if the user did not click on a shape, makes the active shape = null
            Location loc = new Location(event.getX(), event.getY());
            if (world.locationClicked(loc, mineList) == true)
            {
               System.out.println("You lose.");
            }
            else
            {
                int occupiedSpaces = world.getGrid().getOccupiedAdjacentLocations(loc).size();
                if (occupiedSpaces == 0)
                {
                    Zero zero = new Zero();
                    world.getGrid().put(loc,zero);
                }
                else if (occupiedSpaces == 1)
                {
                    One one = new One();
                    world.getGrid().put(loc,one);
                }
                else if (occupiedSpaces == 2)
                {
                    Two two = new Two();
                    world.getGrid().put(loc,two);
                }
                else if (occupiedSpaces == 3)
                {
                    Three three = new Three();
                    world.getGrid().put(loc,three);
                }
                else if (occupiedSpaces == 4)
                {
                    Four four = new Four();
                    world.getGrid().put(loc,four);
                }
                else if (occupiedSpaces == 5)
                {
                    Five five = new Five();
                    world.getGrid().put(loc,five);
                }
                else if (occupiedSpaces == 6)
                {
                    Six six = new Six();
                    world.getGrid().put(loc,six);
                }
                else if (occupiedSpaces == 7)
                {
                    Seven seven = new Seven();
                    world.getGrid().put(loc,seven);
                }
                else if (occupiedSpaces == 8)
                {
                    Eight eight = new Eight();
                    world.getGrid().put(loc,eight);
                }
            }
        }
        public void mouseReleased(MouseEvent event) {}
        public void mouseClicked(MouseEvent event) {}
        public void mouseEntered(MouseEvent event) {}
        public void mouseExited(MouseEvent event) {}
    }
    
    /**
     * Creates an instance of this class. Provides convenient execution.
     *
     */
    public static void main(String[] args)
    {
        Minesweeper game = new Minesweeper();
    }

}