import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Grid;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;
import info.gridworld.world.World;
import java.util.ArrayList;

/**
 * Write a description of class NewGridWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NewGridWorld extends World
{
    /** description of instance variable x (add comment for each instance variable) */

    /**
     * Default constructor for objects of class NewGridWorld
     */
    public NewGridWorld(BoundedGrid<Actor> grid)
    {
        // initialise instance variables
        super(grid);
    }

    /**
     * An example of a method - replace this comment with your own
     *    that describes the operation of the method
     *
     * @pre        preconditions for the method
     *            (what the method assumes about the method's parameters and class's state)
     * @post    postconditions for the method
     *            (what the method guarantees upon completion)
     * @param    y    description of parameter y
     * @return    description of the return value
     */
    public boolean locationClicked(Location locClicked, ArrayList<Location> locMines)
    {
        // put your code here
        boolean b = false;
        
        for(int i = 0; i < locMines.size(); i++)
        {
            if (locClicked.equals(locMines.get(i)))
            {
                b = true;
            }
        }
        
        return b;
    }

}