import info.gridworld.actor.Actor;
import info.gridworld.grid.Location;

public class One extends Actor
{
    public One()
    {
        super();
    }
}