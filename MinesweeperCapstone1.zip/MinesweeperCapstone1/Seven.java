import info.gridworld.actor.Actor;
import info.gridworld.grid.Location;

public class Seven extends Actor
{
    public Seven()
    {
        super();
    }
}