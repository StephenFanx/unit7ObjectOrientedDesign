import info.gridworld.actor.Actor;
import info.gridworld.grid.Location;

public class Six extends Actor
{
    public Six()
    {
        super();
    }
}