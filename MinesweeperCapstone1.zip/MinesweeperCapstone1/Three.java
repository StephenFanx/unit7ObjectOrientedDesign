import info.gridworld.actor.Actor;
import info.gridworld.grid.Location;

public class Three extends Actor
{
    public Three()
    {
        super();
    }
}